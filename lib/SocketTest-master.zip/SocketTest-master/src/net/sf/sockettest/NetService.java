package net.sf.sockettest;

public interface NetService {

    void setUpConfiguration(String ip, String port);
}
