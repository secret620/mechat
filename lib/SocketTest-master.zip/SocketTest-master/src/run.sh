#!/bin/sh

java -jar ../dist/SocketTest.jar c:10.0.0.1:5555